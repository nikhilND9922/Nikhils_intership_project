public class Forest_implementing_Interface {
    public static void main(String[] args){

        Animal_Implementing_interface animal=new Animal_Implementing_interface();
        animal.Walk();

       }



    }


public class Animal_Implementing_interface implements Tiger_implementing_interface {
    public void Walk(){
        System.out.println("All animals are walk");
    }
}

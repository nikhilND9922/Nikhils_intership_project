 interface Tiger_implementing_interface {
     void Walk();

}
